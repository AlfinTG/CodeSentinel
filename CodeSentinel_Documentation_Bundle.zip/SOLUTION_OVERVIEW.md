# CodeSentinel — Solution Overview

**Purpose:** A human-readable explanation of the product concept, problem, user journey, boundaries, and intended value.

**Status:** Concept and planning document. This is not evidence that any feature has been implemented.
**Working name:** CodeSentinel. The team should check name/domain/trademark availability before making the name permanent.
**Target hackathon:** Nebius × NVIDIA Global AI Hackathon, with Coding and Agentic Engineering as the proposed primary track.

## 1. The idea in one minute

CodeSentinel is a developer tool that watches a software repository, identifies code changes, runs relevant tests, and uses an NVIDIA open model served through Nebius Token Factory to help explain failures and propose repairs. Its central promise is:

> Show developers what a change broke, provide evidence for why it broke, and verify whether a proposed fix restores the expected behavior.

It is not merely a Git activity tracker, code-summary chatbot, or passive website uptime monitor. Those may be useful supporting features, but the core value is a traceable **change → test → evidence → diagnosis → proposed fix → verification** loop.

## 2. The problem

A change can compile and still break a different page, API, or user journey. A developer may test only the area they edited and miss an indirect regression. When a problem is found, developers often spend time connecting a code diff with failing tests, logs, and the affected user workflow.

CodeSentinel aims to reduce that investigation effort by linking these pieces together. It cannot guarantee that every future bug will be predicted. It can detect observed failures, compare behavior with a baseline, prioritize likely risk, and explain evidence gathered by deterministic tools.

## 3. Who it is for

- Individual developers working on web applications.
- Small teams shipping frequent changes.
- Hackathon teams using AI coding assistants and wanting to catch regressions quickly.
- Maintainers who need a clear incident history tied to repository changes.

The first version should focus on one repository and one supported application/test setup rather than claiming universal language or framework support.

## 4. How a user experiences it

1. A developer connects a GitHub repository and configures the commands and critical user flows to test.
2. A push or pull request produces a repository event. The backend verifies the webhook signature and records the event idempotently.
3. CodeSentinel identifies the commit/PR diff and queues a test run in an isolated environment.
4. The runner executes configured checks, such as build, lint, type-check, unit tests, and a small number of Playwright browser journeys.
5. If a check fails, CodeSentinel captures structured evidence: command, exit code, relevant output, failed test, URL/route if applicable, and run/commit identifiers.
6. The NVIDIA model on Nebius Token Factory receives a bounded, redacted evidence bundle and proposes a likely cause, affected behavior, confidence, and safe remediation steps.
7. The dashboard distinguishes actual observations from model hypotheses. A proposed patch may be created only in an isolated branch/worktree and only under explicit repository permissions.
8. The same relevant tests run against the proposed patch. The system marks the fix as verified only when the configured checks pass; otherwise it reports that the fix failed or remains unverified.

## 5. What makes the idea stronger than a tracker

The differentiating workflow is evidence-led diagnosis and verification. The system should:

- Link code changes to potentially affected routes, APIs, tests, and user journeys.
- Select relevant tests where safe and explain why those tests were selected.
- Show actual failure evidence before asking the model for an explanation.
- Label confidence and uncertainty instead of presenting model output as truth.
- Verify proposed patches by running tests again.
- Keep a history of confirmed regressions and verified fixes for the repository.

These methods are not all individually novel. The project must demonstrate that the combined workflow is useful, reliable, and coherent.

## 6. What the first version includes

**MVP scope:**

- Connect one GitHub repository through a narrowly scoped integration.
- Accept push and pull-request webhooks with signature validation.
- Store project configuration, events, test runs, findings, and AI analyses.
- Run configured checks in an isolated runner with resource/time limits.
- Support a small, explicit set of browser workflows through Playwright.
- Call at least one NVIDIA open-source model through Nebius Token Factory for evidence-grounded diagnosis.
- Present run status, failed checks, evidence, AI explanation, and remediation proposal in a dashboard.
- Re-run selected checks against a candidate fix in isolation.

**Only after the MVP is reliable:** local uncommitted-file watching, IDE plugins, multi-repository organization features, deeper code graphs, production telemetry integrations, notifications, automatic merging, and broad language support.

## 7. What it does not promise

- It does not prove the absence of all bugs.
- It does not predict every future failure.
- It does not replace a team's test suite or production observability platform.
- It does not silently edit or deploy production code.
- It does not execute repository code with unrestricted access to the host, secrets, or network.
- It does not claim a fix is successful based only on the model's statement.

## 8. Role of Nebius and NVIDIA

The model call must be part of the actual product workflow, not a decorative demo. CodeSentinel uses an NVIDIA open-source model served via Nebius Token Factory to interpret code diffs and test evidence, structure a diagnosis, and propose remediation. The exact model identifier, endpoint, parameters, limitations, and actual behavior must be confirmed and recorded during implementation. Do not hard-code a model name from an example without confirming it is currently available to the team's account.

For the Coding and Agentic Engineering track, the team must re-check the current official rules for any sandbox-specific expectations and implement against the documented platform capabilities actually available. Do not claim Token Factory sandbox execution unless the application genuinely uses that capability.

## 9. How to demonstrate the value

Use a small, controlled sample web application with a known-good baseline and three user journeys. Introduce one deliberate regression that breaks a journey outside the edited component. Demonstrate that:

1. the repository event is captured;
2. the relevant test fails reproducibly;
3. the AI explanation cites real evidence and identifies a plausible cause;
4. a candidate fix is proposed in isolation; and
5. the tests pass after the patch, or the system honestly reports that the attempt did not work.

Track factual demo metrics such as detection latency, number of tests run, test outcome, model latency, and token usage. Do not invent time-saved or accuracy claims from a single demo.

## 10. Success criteria

A successful first version lets a reviewer reproduce the end-to-end workflow from a clean setup; proves Nebius/NVIDIA integration with a real runtime call; distinguishes actual failures from model-generated hypotheses; avoids unsafe production actions; and explains the result clearly without requiring the reviewer to understand the internal architecture.

## 11. Team decisions still required

The documents provide recommended defaults but do not pretend the team has already chosen them. Before implementation, confirm: repository/framework; frontend/backend stack; hosting; database; supported test commands; GitHub integration mode; model available to the team; use of any Token Factory sandbox; patch approval policy; and notification channel. Record final decisions in the architecture and README.

## 12. Reference links

- Hackathon page: https://nebiusglobalaihackathon.devpost.com/
- Official rules: https://nebiusglobalaihackathon.devpost.com/rules
- Hackathon tips: https://nebiusglobalaihackathon.devpost.com/updates/46205-how-to-build-a-winning-project
- Nebius Token Factory / NVIDIA Nemotron overview: https://nebius.com/services/token-factory/nemotron
- Token Factory documentation: https://docs.tokenfactory.nebius.com/
- GitHub webhook signature validation: https://docs.github.com/en/webhooks/using-webhooks/validating-webhook-deliveries
- Playwright documentation: https://playwright.dev/docs/intro
