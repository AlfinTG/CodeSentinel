# Code Style and Repository Conventions

## 1. General rules

- Follow the conventions already established in the repository. This guide does not justify broad rewrites.
- Prefer clear, explicit code over clever abstractions.
- Keep functions focused and modules cohesive.
- Name variables and functions for the domain meaning: `run_status`, `delivery_id`, `evidence_item`, `patch_attempt`.
- Avoid magic strings and numbers for states, timeouts, size limits, and policy settings; centralize configuration.
- Validate untrusted data at system boundaries.
- Add comments for security decisions and non-obvious behavior, not for every line.
- Do not leave debug output, dead code, TODO-only implementations, or fake successful responses in production paths.

## 2. TypeScript/frontend (if used)

- Use strict TypeScript settings where the existing stack allows.
- Define shared types for API payloads and run/check states.
- Keep components focused; separate API access and domain logic from presentation.
- Use the application's existing design tokens, routing, and state conventions.
- Handle loading, empty, error, unauthorized, and partial-result states.
- Avoid `any` unless justified at a boundary and narrowed immediately.
- Never place server secrets in client-side variables, bundled configuration, or browser storage.

## 3. Python/backend (if used)

- Use type annotations on public functions and external boundaries.
- Validate inputs with the project's established schema framework.
- Use a shared provider adapter rather than scattering raw model HTTP calls throughout the app.
- Use explicit exceptions or result types for expected failures; do not hide errors with blanket exception handlers.
- Use structured logging and redact sensitive values.
- Keep webhook validation, event normalization, run coordination, test execution, model analysis, and persistence as distinct responsibilities.
- Avoid starting long jobs directly inside webhook request handlers.

## 4. API and data contracts

- Version API contracts where it is appropriate for the project's maturity.
- Use explicit status/state enums and document allowed transitions.
- Return stable safe error codes with useful client messages; never return stack traces or secrets to end users.
- Reject unknown or malformed state transitions.
- Keep model output schema separate from the application's persisted schema.
- Validate all model-supplied file paths, line references, evidence identifiers, and patch metadata before use.

## 5. Error handling

- Distinguish expected provider/runner errors from application defects.
- Preserve actual runner exit status even if the AI provider is down.
- Add timeouts to network calls and long-running processes.
- Retry only transient failures, with bounded attempts and backoff.
- Make non-idempotent operations safe against retries before adding automatic retry logic.
- Show whether a result failed, timed out, was cancelled, was skipped, or was never attempted.

## 6. Testing and pull requests

- Add tests for bug fixes and new behavior.
- Keep tests deterministic and independent of personal credentials.
- Mock provider calls for ordinary unit tests; add a separate opt-in integration test for real provider connectivity.
- Describe security-relevant changes in the pull request.
- Run the relevant project checks and report the actual outcomes.
- Do not claim “all tests pass” if a suite was skipped or a command failed.

## 7. Dependencies and configuration

- Use the committed lockfile and existing package manager.
- Add dependencies only when they solve a concrete need.
- Prefer maintained, well-documented libraries.
- Keep deployment config consistent with local config examples.
- `.env.example` must contain placeholders only; local `.env` must be ignored by version control.

## 8. UI and accessibility

- Use semantic elements and accessible labels.
- Ensure the interface works with keyboard navigation and visible focus.
- Do not encode status using color alone; include text/icon labels.
- Keep spacing, typography, and interaction patterns consistent with `DESIGN_SYSTEM.md`.
- Do not use fake counts, fake repository events, fake AI analyses, or invented confidence values to make the UI look complete.
