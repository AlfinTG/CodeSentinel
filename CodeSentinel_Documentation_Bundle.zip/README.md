# CodeSentinel — AI-Assisted Regression Detection

> Working project name. CodeSentinel connects repository changes to automated tests and evidence-based AI diagnosis, then verifies whether proposed fixes work.

## Status

This repository documentation defines the intended product and implementation guidance. It is not proof that the application has already been built. Update this section as code and deployment become real.

## Why it exists

A code change can break a different route or user journey even when the build succeeds. CodeSentinel aims to detect reproducible regressions, connect them to relevant changes, explain the evidence, and safely test a proposed fix.

## Core workflow

`GitHub event → verify event → inspect change → isolated test run → collect evidence → NVIDIA model on Nebius Token Factory → diagnosis/proposed patch → rerun tests → report verified outcome`

**Truth rule:** test runners and observed application behavior establish pass/fail status. The model provides hypotheses and suggested actions. A fix is not labelled verified until the configured checks actually pass.

## Documentation map — all files are in this folder

- `SOLUTION_OVERVIEW.md` — human-readable product concept and intended user journey.
- `PRD.md` — users, requirements, MVP scope, acceptance criteria, and non-goals.
- `ARCHITECTURE.md` — components, boundaries, event flow, and recommended reference stack.
- `DATABASE.md` — proposed records, relationships, and retention guidance.
- `SECURITY.md` — threat model and security requirements.
- `TESTING.md` — automated testing strategy and demo acceptance checks.
- `DESIGN_SYSTEM.md` — interface principles, layout, status semantics, and visual tokens.
- `CODE_STYLE.md` — coding and repository conventions.
- `AGENTS.md` — persistent instructions for coding agents.
- `CREATE_PROMPT.md` — prompt to give an implementation agent to build the application.
- `INSTALL_PROMPT.md` — prompt to give an agent when installing, configuring, and validating the project.
- `SETUP AND CREATION GUIDE.md` — human-oriented implementation sequence and local setup guide.

All Markdown documents are deliberately in one flat folder, as requested. Do not move them into a nested `docs/` directory unless the team explicitly changes this decision.

## Current implementation decisions

The architecture document contains suggested defaults. A coding agent must first inspect the existing repository and follow its actual framework, commands, and conventions where they exist. If the repository is empty, ask the project owner to confirm the recommended reference stack before creating a large application scaffold. Never claim an API, command, model availability, test result, or deployment status without verifying it.

## Hackathon fit

Proposed primary track: **Coding and Agentic Engineering**. The application must make a real runtime call to an eligible NVIDIA open-source model through Nebius Token Factory or meet the official rules through Nebius AI Cloud. Re-check the current rules and track-specific requirements before submission. Clearly explain how the model is used; do not add a token-factory badge to an otherwise unrelated application.

## Setup

No runnable application code is included in this documentation-only bundle. After implementation, replace this section with the verified prerequisites, exact install commands, environment variables, database migration steps, run commands, tests, and deployment process. Do not invent commands in advance.

## Environment and secrets

Use environment variables or a local ignored `.env` file for credentials. Never commit `NEBIUS_API_KEY`, GitHub tokens, webhook secrets, OAuth secrets, production credentials, or test data containing secrets. Provide `.env.example` with names and safe placeholders only when implementation begins.

## Demo plan

Use a small sample application with a passing baseline. Introduce a controlled regression; show the actual failing test, the relevant code change, the AI explanation, the proposed fix, and the rerun outcome. The system must accurately report failure if its patch does not resolve the issue.

## Required public repository checks before submission

- Add an appropriate open-source `LICENSE` file after the team confirms the chosen license.
- Ensure README setup instructions work from a clean environment.
- Remove credentials, private data, temporary logs, and generated artifacts.
- Include the actual deployment/demo URL and a public repository URL in the final submission description.
- Include a public demo video within the hackathon's stated length limit.
- Explain the actual model and Nebius services used and give specific feedback requested by the organizers.

## Official and technical references

- Hackathon overview and rules: https://nebiusglobalaihackathon.devpost.com/ and https://nebiusglobalaihackathon.devpost.com/rules
- Nebius/NVIDIA Nemotron: https://nebius.com/services/token-factory/nemotron
- Token Factory docs: https://docs.tokenfactory.nebius.com/
- GitHub webhook security: https://docs.github.com/en/webhooks/using-webhooks/validating-webhook-deliveries
- Playwright: https://playwright.dev/docs/intro
