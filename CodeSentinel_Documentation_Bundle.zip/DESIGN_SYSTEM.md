# Design System

## 1. Product experience goal

CodeSentinel is a technical tool, but its interface should make complex failure evidence legible at a glance. The user should answer these questions quickly: What changed? Did a test actually fail? What evidence proves it? What does the AI think? Has the suggested fix been verified?

## 2. Visual direction

Use a clean, high-contrast developer-tool interface rather than a generic “AI dashboard.” Suggested palette: graphite/near-black base; neutral gray surfaces; red for confirmed failures; yellow/amber for warnings and unverified/risky states; green for passing checks; blue for informational links and primary actions. Reserve bright accents for meaningful statuses, not decoration. Verify contrast before finalizing exact colors.

Suggested token starting points (adjust after accessibility checks):

- `--color-bg`: `#0B0D10`
- `--color-surface`: `#14181E`
- `--color-surface-raised`: `#1C222B`
- `--color-border`: `#343B46`
- `--color-text`: `#F4F6F8`
- `--color-text-muted`: `#B2BAC5`
- `--color-danger`: `#F04438`
- `--color-warning`: `#F5B942`
- `--color-success`: `#28C76F`
- `--color-info`: `#4D9EFF`

These are proposed starting tokens, not implemented facts. The team should test contrast and tune them against real components.

## 3. Navigation and main screens

### Projects / repositories

- Show repository identity, connection state, last activity, and recent run status.
- Do not show fabricated test counts or connection status.
- Provide a clear path to connect/configure a repository.

### Run list

- Show source revision/PR, event time, overall test status, analysis status, duration when known, and one-line factual summary.
- Separate test outcome from AI-analysis outcome. For example, tests may fail even if AI analysis fails due to a provider outage.
- Provide filters only where supported by actual data.

### Run details

Recommended order:

1. Header with repository, short commit SHA, source event, timestamps, and status.
2. Summary of confirmed outcomes.
3. Checks table with status, duration, and details.
4. Evidence panel with failed assertions/log snippets and source references.
5. AI diagnosis panel with “Observed evidence” and “Model interpretation” clearly separated.
6. Suggested fix / candidate diff, if implemented.
7. Validation outcome and history of attempts.

### Project settings

Keep repository access, test commands, critical journeys, and integration health understandable. Dangerous permissions or write access need a clear explanation and explicit confirmation.

## 4. Status vocabulary

Use a small consistent set:

- **Queued** — accepted and waiting for runner.
- **Running** — execution is active.
- **Passed** — all checks required by that run passed.
- **Failed** — at least one required check failed.
- **Timed out** — an execution limit was reached.
- **Cancelled** — intentionally stopped.
- **Error** — the system could not complete a reliable assessment.
- **Partial / Incomplete** — only some required checks ran or produced results.
- **Analysis unavailable** — tests may still have results, but model analysis did not complete.
- **Fix verified** — the candidate fix passed the explicitly listed required checks; never use for an untested patch.
- **Unverified** — insufficient evidence to claim the outcome.

Do not rely on color alone. Include text labels and accessible icon labels.

## 5. AI output presentation

The model response should not dominate the page. Present concise sections:

- Likely cause (clearly marked as a hypothesis).
- Evidence supporting it, linked to actual check/evidence records.
- Affected behavior and potential impact.
- Confidence/uncertainty with an explanation; do not imply a calibrated probability if no calibration exists.
- Suggested fix and regression test.
- Verification status after actual test execution.

If the model cannot explain a failure from available evidence, it should say what evidence is missing rather than inventing a cause.

## 6. Components and states

Define reusable components for status badges, check rows, evidence blocks, code diffs, confirmation dialogs, timestamps, empty states, error states, and retry actions. Include disabled/loading states. Avoid flashing or animation that distracts from diagnostics.

## 7. Typography and layout

- Use readable UI typography for summaries and monospace only for code, hashes, commands, and logs.
- Favor a clear hierarchy over dense cards with many unrelated metrics.
- Allow long logs and diffs to wrap or scroll without breaking the page.
- Design desktop-first for developer workflows but ensure core run details remain usable on tablet/mobile.
- Use consistent spacing and alignment; put the most important failure evidence above secondary analytics.

## 8. Accessibility and trust

- Meet WCAG contrast expectations where feasible and test contrast for the final palette.
- Ensure full keyboard navigation and visible focus.
- Use semantic headings, labelled forms, and announcements for async status changes.
- Distinguish actual data from demo fixtures and clearly label any demo-only content.
- Do not use “AI fixed it” or “production safe” without a defined and verified basis.
