# Database and Data Model

## 1. Purpose

This document defines a proposed persistence model for CodeSentinel. Names and types are logical guidance; adapt them to the actual ORM and database selected by the team. Do not create unused tables simply because they appear here.

## 2. Recommended records

### `users` (only if the app owns authentication)

- `id` — primary key.
- `email` or external identity reference — unique where appropriate.
- `created_at`, `updated_at`.

If authentication is delegated to a verified identity provider, store only the identity fields the app needs. Do not build a custom password system by default.

### `projects`

- `id` — primary key.
- `owner_id` — owner/team authorization reference.
- `name` — user-facing project name.
- `repository_provider` — initially `github` if that's the implemented provider.
- `repository_id` — stable provider repository identifier where available.
- `repository_owner`, `repository_name` — display/lookup metadata.
- `default_branch` — if supplied/confirmed by provider.
- `configuration_json` — validated, non-secret test and journey configuration.
- `created_at`, `updated_at`, `archived_at` nullable.

Keep installation tokens, private keys, and webhook secrets in secret storage or encrypted secret fields with strict access—not in ordinary configuration JSON.

### `webhook_deliveries`

- `id` — primary key.
- `provider`.
- `delivery_id` — unique provider delivery identifier scoped to the provider/integration.
- `project_id` — resolved project, nullable if rejected before resolution.
- `event_type`.
- `received_at`.
- `signature_valid` boolean.
- `processing_status` — accepted, ignored, rejected, failed, etc.
- `safe_error_code` nullable.

Do not store an unbounded full webhook body by default. If a specific payload field is needed for debugging, store a minimized and redacted form with a retention limit.

### `runs`

- `id` — primary key.
- `project_id`.
- `delivery_id` or originating event reference, nullable for manual runs.
- `source_type` — push, pull request, manual, scheduled, etc. only for implemented types.
- `source_revision` — commit SHA or equivalent immutable revision.
- `base_revision` nullable.
- `pull_request_number` nullable.
- `status` — queued/running/completed/failed/timed_out/cancelled/rejected.
- `test_status` — passed/failed/partial/not_run/timed_out.
- `analysis_status` — pending/completed/failed/not_requested.
- `started_at`, `completed_at`, `created_at`.
- `runner_version` or config fingerprint where useful.
- `summary` — generated from actual results, not just AI text.

### `checks`

- `id` — primary key.
- `run_id`.
- `name` — stable configured check name.
- `check_type` — build, lint, typecheck, unit, browser, API, etc.
- `status` — queued/running/passed/failed/timed_out/cancelled/skipped/error.
- `exit_code` nullable.
- `started_at`, `completed_at`, `duration_ms` nullable.
- `report_reference` nullable.
- `safe_error_code` nullable.

### `evidence_items`

- `id` — primary key.
- `run_id`.
- `check_id` nullable.
- `evidence_type` — test_failure, stack_trace, console_error, http_response, screenshot, diff_reference, etc.
- `title`.
- `content_redacted` or safe structured metadata.
- `source_locator` — file/line, test name, URL route, or artifact reference as applicable.
- `created_at`.
- `expires_at` nullable.

Large screenshots/log artifacts may belong in private object storage; store a restricted reference and checksum rather than huge blobs. Apply retention and access checks.

### `analyses`

- `id` — primary key.
- `run_id`.
- `provider` — e.g. Nebius Token Factory.
- `model_id` — the exact identifier used at runtime.
- `status` — pending/completed/failed/invalid_response.
- `input_fingerprint` or prompt version, not an unbounded raw secret-bearing prompt.
- `summary`, `likely_cause`, `impact`, `confidence_label` or bounded score with explanation.
- `evidence_ids` — preferably normalized relation table if queryability is needed.
- `suggested_actions` — structured JSON validated against schema.
- `created_at`, `completed_at`.
- `provider_request_id` and usage fields only when returned and safe to store.

### `patch_attempts` (P1, only if patch generation is implemented)

- `id` — primary key.
- `run_id`, `analysis_id`.
- `source_revision`.
- `patch_reference` or candidate branch/worktree identifier.
- `status` — proposed/applied_in_isolation/testing/passed/failed/rejected/discarded.
- `started_at`, `completed_at`.
- `validation_summary` derived from actual checks.
- `approved_by` and `approved_at` for any explicitly approved external action.

Never store a patch as verified just because the model says it is correct.

## 3. Relationships

- One project has many webhook deliveries and runs.
- One accepted delivery may create at most one logical run for its event/revision under the idempotency policy.
- One run has many checks and evidence items.
- One run may have multiple analyses and patch attempts, especially across retries.
- An analysis references the exact run/evidence snapshot it evaluated.

## 4. Constraints and indexes

- Unique key on provider delivery id in its appropriate integration scope.
- Index runs by `project_id`, `created_at`, and status for dashboard queries.
- Index checks/evidence by `run_id` and creation order.
- Foreign keys and deletion behavior should preserve audit consistency while honoring project removal/retention policy.
- Enforce permitted enum/state transitions in application logic and, where suitable, database constraints.

## 5. Data handling and retention

- Store the smallest amount of source code/log content needed for useful diagnostics.
- Redact tokens, passwords, private keys, connection strings, and personal data before persistence and model submission.
- Use a retention policy for logs, screenshots, prompts, and artifacts.
- Provide a way to unlink a repository and delete or archive its project data according to the app's defined policy.
- Avoid using private repository content for model training; do not make claims about provider data handling that have not been checked in the applicable terms/settings.

## 6. Migrations and development fixtures

Use the chosen framework's versioned migrations. Keep schema changes reviewable and reversible where practical. Demo fixtures must be clearly marked as fixtures and must never appear as real GitHub events or live model results. Test data should not contain working credentials.
