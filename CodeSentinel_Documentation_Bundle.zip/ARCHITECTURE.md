# Architecture

## 1. Architecture goals

- Make the change-to-verified-outcome workflow explicit and observable.
- Keep untrusted repository execution separate from the web/API process.
- Keep the Nebius/NVIDIA model integration behind a server-side adapter.
- Distinguish source-of-truth observations from AI-generated interpretation.
- Be small enough for a hackathon team to implement and debug.

## 2. Proposed logical components

1. **Web UI** — project configuration, run list, run details, evidence, AI analysis, remediation status.
2. **API** — authentication, authorization, repository settings, run state, evidence retrieval, and UI-facing endpoints.
3. **GitHub integration** — receives webhooks, verifies signatures, checks event types, prevents duplicate delivery processing, records changes.
4. **Run coordinator** — creates run jobs and manages allowed states, timeout/cancellation, retry boundaries, and results.
5. **Isolated runner** — checks out the pinned commit/PR revision and runs configured allowlisted checks in a restricted environment.
6. **Evidence normalizer** — converts process exit results, test reports, browser results, and bounded logs into a consistent evidence bundle while redacting secrets.
7. **AI provider adapter** — makes authenticated calls to the currently documented Nebius Token Factory API using a confirmed NVIDIA open-source model.
8. **Diagnosis validator** — parses and validates structured model output, ensures evidence references correspond to actual records, and rejects malformed output.
9. **Persistence layer** — stores projects, repository links, delivery identifiers, runs, checks, findings, analyses, and patch attempts.

## 3. Suggested reference stack (not a fact about an existing repository)

If there is no existing stack, evaluate these defaults with the team:

- Frontend: React + TypeScript.
- Backend: Python + FastAPI.
- Persistent data: PostgreSQL.
- Browser checks: Playwright.
- Runner isolation: dedicated worker plus container or a verified provider sandbox.
- Model serving: Nebius Token Factory's currently documented API; NVIDIA Nemotron is a candidate family, but confirm the exact model identifier and availability.

Choose the simplest working infrastructure that meets isolation needs. A Redis queue, Kubernetes, complex event bus, and multi-agent framework are not required for the initial vertical slice unless the chosen hosting/runtime makes one necessary. Existing repository conventions take precedence over the proposal after inspection.

## 4. Main event flow

1. GitHub sends a push or pull-request event to the configured webhook endpoint.
2. API reads the unmodified raw body and validates `X-Hub-Signature-256` with HMAC-SHA256 using a secret stored outside source control. Compare signatures in constant time.
3. Validate event type, repository installation/project access, and payload shape. Reject unsupported events safely.
4. Store the GitHub delivery id under a unique constraint. Duplicate delivery returns a safe successful acknowledgement without creating duplicate work.
5. Create a run referencing repository, event, base/head commit or PR, and configured checks.
6. Run coordinator queues the task. Runner fetches only the authorized repository/revision, uses restricted credentials where unavoidable, runs allowlisted checks with timeout and CPU/memory/log limits, and returns structured results.
7. Evidence normalizer stores exit codes, test results, bounded output, and safe links. Secret redaction occurs before persistence and before model submission.
8. If analysis is warranted, the backend sends the minimal relevant context to the model adapter. Include the relevant diff/hunks, failed assertions, stack trace fragments, route/result metadata, and baseline context as available.
9. Validator stores structured diagnosis and references to observed evidence.
10. UI displays test facts and AI hypotheses separately. Optional patch workflow creates a candidate in a separate branch/worktree/sandbox and reruns relevant tests.
11. Run summary reports pass/fail/error/timeout/cancelled and remediation status separately. The diagnosis cannot override the test state.

## 5. Component boundaries

- The frontend never talks directly to Nebius using a secret key.
- The webhook handler should validate and persist/enqueue quickly; it should not synchronously run a long test suite in the request lifecycle.
- The runner should have no access to application database credentials unless a specific test requires a restricted test database.
- The AI adapter must not execute commands or write repository files on its own.
- The patch service, if present, applies a validated diff in an isolated context and is separate from main-branch deployment.
- Results must be linked to a pinned source revision so later repository changes do not silently alter evidence.

## 6. Run state model

Suggested top-level states:

`received → queued → running → collecting_evidence → analyzing → completed`

Terminal alternatives: `failed`, `timed_out`, `cancelled`, `rejected`, `provider_error`.

Prefer structured fields over a single overloaded status. A run may have a test status (`passed`, `failed`, `timed_out`, `not_run`) and a separate analysis status (`pending`, `completed`, `failed`, `not_requested`). A model service failure must not overwrite a real test failure.

## 7. API design guidance

Use versioned and documented endpoints where appropriate. Example resource boundaries—not a commitment to exact URLs:

- projects/repositories: create, read, update, unlink;
- webhook endpoint: validate provider event and enqueue;
- runs: list, read, cancel when safe;
- checks/evidence: read bounded details;
- analyses: request/retrieve validated output;
- patch attempts: create candidate, inspect diff, request validation, discard candidate.

Every resource endpoint must enforce authentication and project-level ownership/authorization. Never trust project or run IDs supplied by a client without checking access.

## 8. Repository integration options

For an MVP, use a GitHub App or a narrowly scoped token approved by the team. Prefer the least privileges and short-lived credentials practical. The application needs read access to the repository/revision to run checks; write access should be added only if the team implements an explicitly approved branch/PR workflow. Webhook secrets and app private keys must stay server-side.

## 9. Execution isolation

Running arbitrary repository build scripts is code execution. A container is not automatically safe just because it is a container. At minimum:

- run as a non-root user;
- mount only needed workspace paths;
- do not mount host Docker sockets;
- block or restrict outbound network by default;
- do not pass production secrets into the runner;
- set CPU, memory, process, disk, log-size, and wall-clock limits;
- destroy ephemeral workers/workspaces after use;
- pin the commit and dependencies as much as feasible;
- allow only project-owner-configured commands, not model-generated shell commands.

If the hackathon track requires Token Factory sandboxes, verify the currently documented API and use it where actually supported. Do not equate model inference on Token Factory with sandboxed code execution.

## 10. Failure handling

- Provider timeout/rate limit: keep test facts; mark analysis unavailable and permit safe retry.
- Runner lost/timed out: report runner failure, not application test pass/fail unless results prove it.
- Malformed AI response: reject the analysis, store a safe error code, and do not display raw untrusted payload as trusted markup.
- Duplicate webhooks: idempotent response, one logical run.
- Out-of-order updates: use explicit state transition rules and revision/attempt identifiers.
- Partial checks: show each check independently and label the aggregate as incomplete where appropriate.

## 11. Observability

Use structured logs with correlation identifiers such as project id, delivery id, run id, check id, and patch-attempt id. Never log credentials or full unredacted prompts. Record durations and error codes. Use actual provider usage fields only where the API returns them; avoid invented cost/latency metrics.

## 12. Architecture decisions to record before coding

- Current repository stack and deployment target.
- GitHub App versus fine-grained token / OAuth approach.
- Runner platform and sandbox strategy.
- Database and migration approach.
- Exact Nebius endpoint/SDK and NVIDIA model identifier.
- Whether patch creation is included in MVP.
- Browser journeys and supported test commands.
- Data retention limits and authorization model.
