# Installation and Validation Prompt

Use this prompt after the implementation agent has created application code, or when asking an agent to set up an existing checkout.

---

Read `AGENTS.md`, `README.md`, `ARCHITECTURE.md`, `SECURITY.md`, and `TESTING.md`. Then set up this project **based on the files that actually exist**.

1. Inspect the repository and identify the package manager, runtime version, services, migration system, and documented setup commands. Do not guess. If required setup information is missing, report the gap and propose a minimal correction.
2. Check prerequisites and versions. Do not upgrade dependencies broadly without cause.
3. Install dependencies using the committed lockfile and the repository's package manager.
4. Create or validate a local environment file from `.env.example` if it exists. Do not ask the user to paste secrets into chat. Never print secrets to terminal output or logs.
5. Configure the minimum required variables for local operation. Document which integrations can run in test mode and which need real credentials.
6. Apply database migrations using the actual documented command, if a database is part of the implementation.
7. Run formatting/linting, type checks, unit tests, integration tests, and build commands that are actually present in the repository. Report exact commands and outcomes.
8. Run the app locally if environment support permits and check its health route/UI. Do not claim to have checked a browser if no browser tool or runnable server is available.
9. Validate Nebius Token Factory configuration with a minimal real request only if a valid key is already securely configured. Never echo the key. Record the actual model identifier and response status; if credentials are absent, label the integration as not verified.
10. Validate webhook processing using tests or a safe local fixture. Include invalid-signature and duplicate-delivery cases. Do not claim to have received a real GitHub webhook unless that happened.
11. Verify that untrusted test jobs are bounded/isolated, model-proposed commands are not executed arbitrarily, and repository secrets are not returned to the UI or AI prompt.
12. Update the README with only verified install/run/test commands and the actual required environment variables.

Finish with a concise report: prerequisites, exact commands, passed/failed/not-run checks, needed credentials, migration status, local URL only if the server really started, and remaining blockers. Do not silently suppress errors or fabricate success.
