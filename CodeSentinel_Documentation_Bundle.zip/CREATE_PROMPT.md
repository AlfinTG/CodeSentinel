# Implementation Prompt — Build CodeSentinel

Copy this prompt into the coding agent used by the team. Keep the accompanying Markdown files available as project context.

---

You are the senior engineer implementing **CodeSentinel**, an evidence-based AI-assisted regression detection and repair-verification tool. Read `AGENTS.md`, `SOLUTION_OVERVIEW.md`, `PRD.md`, `ARCHITECTURE.md`, `DATABASE.md`, `SECURITY.md`, `TESTING.md`, `DESIGN_SYSTEM.md`, and `CODE_STYLE.md` before making changes.

## First action: inspect, do not assume

Inspect the actual repository and identify its current stack, existing routes/components, database approach, test commands, deployment configuration, and uncommitted work. Preserve working conventions and avoid overwriting user changes. If this repo already contains an application, extend it. If it is empty, present the proposed stack from `ARCHITECTURE.md` and ask for confirmation before creating a major scaffold. Do not claim undocumented integrations or features exist.

## Product outcome

Deliver a working vertical slice:

1. A user configures/connects one GitHub repository using the least privileges practical.
2. A GitHub push or pull-request event reaches the backend. Verify `X-Hub-Signature-256` using HMAC-SHA256 over the original raw request body and constant-time comparison. Reject invalid signatures and safely handle duplicate deliveries.
3. The backend records a run and identifies the commit/PR change context.
4. A bounded, isolated runner executes configured allowlisted checks and a small set of reproducible browser tests. Do not execute untrusted repository code with unrestricted host access.
5. The app stores observed results, logs with secrets redacted, and run status.
6. The backend invokes an NVIDIA open-source model that is available through Nebius Token Factory. Read the current provider docs and account model list at implementation time; use environment-based credentials and the documented endpoint/SDK. Do not hardcode a guessed or stale model identifier.
7. The model returns a structured, validated diagnosis with evidence references, likely cause, impact, confidence, and suggested remediation. Label it as AI-generated and unverified.
8. A user can view the run in a clean dashboard, see which checks failed, inspect evidence, and request a candidate patch through a bounded workflow.
9. If a patch workflow is implemented, apply it only in an isolated branch/worktree or sandbox, run the same relevant tests, and report the actual observed outcome. Never auto-merge or deploy.

## MVP must prioritize

- One repository and one supported stack/test command configuration.
- Reliable webhook ingestion and run status persistence.
- Real deterministic test execution.
- Real Nebius/NVIDIA model inference.
- Evidence-grounded diagnosis.
- A simple, polished run detail interface.
- Error, loading, empty, timeout, and cancellation states.
- Reproducible tests and honest setup documentation.

Do not begin with organization accounts, multiple Git providers, an IDE extension, local uncommitted-file watcher, broad language support, production write access, automatic merges, elaborate agent swarms, or a large analytics suite. Add those only if the core workflow is complete and the team explicitly prioritizes them.

## UI expectations

Follow `DESIGN_SYSTEM.md`: professional high-contrast developer tooling, graphite/near-black surfaces with restrained red, yellow, and green status accents and blue for informational actions. Keep typography readable, spacing consistent, and screens uncluttered. Do not use fake metrics or decorative AI claims. Clearly distinguish observed test outcomes from model hypotheses.

## Required engineering behavior

- Inspect before creating or changing files.
- Use typed request/response structures, input validation, clear error handling, and safe database migrations.
- Validate and authorize access to every project/run endpoint.
- Apply timeouts and resource caps to repository test jobs.
- Use an allowlist for runner commands configured by the project owner; never trust model-generated shell commands.
- Keep credentials server-side and never commit secrets.
- Make webhook processing idempotent using GitHub delivery identifiers and database constraints where applicable.
- Add tests for security-sensitive behavior, state transitions, AI response validation, and the core failure-to-fix flow.
- Do not use fake provider responses as if they were successful real calls. Tests may use mocks but must be labelled as tests.
- Record setup and operational limitations accurately.

## Definition of done

A reviewer can follow the documented setup, configure credentials, connect or simulate a valid test event in a documented manner, run a controlled regression scenario, see deterministic test evidence, receive a real model analysis via Nebius Token Factory, and inspect a truthful outcome. The repo includes repeatable tests, environment examples without secrets, and accurate instructions.

## Final response required

After implementation, report changed files, architecture choices, commands run, test results, missing credentials/manual steps, security boundaries, and known limitations. If anything is blocked, say exactly what and do not report completion prematurely.
