# Setup and Creation Guide

This guide is for teammates who need to understand how the solution should be planned, built, run, and demonstrated. The repository-specific setup commands must be filled in only after the actual code stack exists.

## 1. Before coding

1. Read `SOLUTION_OVERVIEW.md` to understand the product.
2. Read `PRD.md` to understand what is in and out of scope.
3. Read `ARCHITECTURE.md` and agree on stack, runtime isolation, repository integration, and model call boundaries.
4. Read `SECURITY.md` before connecting GitHub or executing repository code.
5. Choose a small sample repository/application that the team controls and can safely break and repair.
6. Confirm the current hackathon rules, team eligibility, track expectations, submission checklist, model availability, and service access.

## 2. Recommended implementation sequence

### Stage A — establish the happy path

- Create the app shell and project/run data model.
- Connect one repository using an authorized mechanism.
- Implement webhook signature validation and duplicate-delivery protection.
- Create a persisted run for a valid push or pull request.
- Show the run status in the UI.

**Exit check:** valid event creates one visible run; invalid signature is rejected; a repeated delivery does not create a duplicate run.

### Stage B — run deterministic checks

- Support configured allowlisted commands.
- Execute jobs in an isolated environment with wall-clock and resource limits.
- Capture exit status, duration, structured test results where available, and bounded logs.
- Add one or more Playwright journeys for a controlled sample application.

**Exit check:** introduce a known regression and reproduce it reliably from a clean baseline.

### Stage C — connect Nebius and NVIDIA

- Verify access and billing/credits with the team's Nebius account.
- Confirm the exact NVIDIA open-source model identifier available through Token Factory.
- Configure the API key as a secret environment variable.
- Implement a small, server-side provider adapter with timeout, error handling, bounded input, and schema validation.
- Send only relevant redacted diff and failure evidence.
- Record actual model usage and provider errors without logging credentials.

**Exit check:** a real request reaches the chosen model and produces a validated analysis. A mocked call is not sufficient evidence of provider integration.

### Stage D — build diagnosis and remediation UI

- Display actual failures first.
- Display AI explanation as a separate section with evidence references and confidence.
- Include a proposed fix and a clear approval boundary.
- If the patch workflow is feasible, apply the candidate only in an isolated branch/worktree or provider sandbox and rerun the relevant tests.

**Exit check:** the system can honestly show pass, fail, or unverified results for the candidate fix.

### Stage E — polish and submit

- Add empty/loading/error states, keyboard focus, responsive layout, helpful timestamps, and accessible status text.
- Run the complete documented test sequence from a clean checkout.
- Prepare the public repository, open-source license, README, deployment/demo URL, and short public demo video.
- Capture the actual model/service names and provide specific feedback requested by the hackathon organizers.

## 3. Recommended reference stack (confirm before implementation)

If the repository is empty and the team has not chosen a stack, a pragmatic option is:

- Frontend: React + TypeScript.
- Backend API: Python + FastAPI.
- Browser end-to-end tests: Playwright.
- Database: PostgreSQL for persistent project, event, run, and finding records.
- AI provider: Nebius Token Factory using its currently documented OpenAI-compatible API where applicable.
- Job execution: a separate worker/runner process. For a first local prototype, keep the runner separate from the API process and place it in a container or other restricted execution boundary.

This is a recommendation, not a claim that the repository already uses these tools. If the team chooses another stack or the repo already uses one, update the architecture and instructions consistently.

## 4. Environment variables

Define only variables actually consumed by the implementation. Likely categories include:

- `NEBIUS_API_KEY` — server-side model API credential.
- `NEBIUS_MODEL` — exact model identifier confirmed at setup time.
- `GITHUB_WEBHOOK_SECRET` — webhook signature secret.
- `GITHUB_APP_ID`, private key, OAuth credentials, or token — only if the chosen GitHub integration actually needs them.
- `DATABASE_URL` — if PostgreSQL is used.
- `APP_BASE_URL` — if callbacks or generated links require it.

Use `.env.example` with blank or placeholder values. Put local `.env` files in `.gitignore`. Do not expose server-only values to frontend bundles. Do not create fake values that appear real.

## 5. Local development procedure

After implementation, document the exact order here with verified commands:

1. Install required runtime(s).
2. Install frontend/backend dependencies using committed lock files.
3. Copy `.env.example` to the local env file and populate needed credentials securely.
4. Start the database and apply migrations, if applicable.
5. Start the API and job worker.
6. Start the frontend.
7. Run unit/integration/browser tests.
8. Open the locally reported URL and trigger the documented sample workflow.

Do not add unverified commands to the final README. The implementation agent must fill them after inspecting `package.json`, lock files, dependency metadata, and migration files.

## 6. Team responsibilities to assign

Assign owners rather than letting critical tasks remain implicit:

- Repository integration and secure webhook handling.
- Test runner and sample regression scenario.
- Nebius/NVIDIA model adapter and evaluation of analysis quality.
- Frontend/run history/incident details.
- Deployment, README, license, demo video, and submission quality checks.

One person can own multiple responsibilities, but every acceptance criterion should have an owner.

## 7. Demo rehearsal checklist

- Use a repository and credentials the team is authorized to access.
- Confirm the known-good commit passes.
- Introduce the planned bug and confirm the chosen test fails before the show.
- Confirm the dashboard displays the real failing test and relevant code change.
- Confirm the model call is live and the correct model/provider are shown in the project description.
- Confirm the proposed repair is not merged or deployed automatically.
- Show the actual result after rerunning tests.
- If any step fails, have an honest fallback recording of a previously verified run; do not present static screenshots or canned output as live execution.

## 8. Submission safety and completeness

Check the latest official rules on the submission day. The supplied hackathon page states that a working app, a track, a project description, a working demo URL, a public source repository with an open-source license, setup instructions, a short public demo video, and specific feedback on tools used are required. Verify the current rules for exact wording and any track-specific conditions.
