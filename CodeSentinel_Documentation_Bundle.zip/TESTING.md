# Testing Strategy

## 1. Testing goal

Prove the complete workflow with repeatable evidence: a repository event is accepted securely, the expected revision is tested, a regression is reproduced, a model diagnoses real evidence, and a proposed fix is re-tested without unsafe side effects.

## 2. Testing layers

### Unit tests

Test isolated logic, including:

- HMAC webhook signature generation/verification and invalid signature rejection.
- Payload schema validation and event-type filtering.
- Delivery idempotency logic and run-state transitions.
- Secret/log redaction.
- Test selection and evidence normalization.
- Model-response schema validation, invalid evidence IDs, overly long fields, and malformed output.
- Permission checks and status aggregation.

### Integration tests

Use a disposable test database and safe fixtures to test:

- Valid event → delivery record → one run.
- Duplicate delivery → no duplicate run.
- Runner result → check/evidence persistence.
- Provider adapter timeout/rate-limit/error behavior.
- Actual provider connectivity when credentials are securely configured (separate from mocked unit tests).
- Project/resource authorization at API boundaries.

### Runner tests

- Test command allowlist is enforced.
- A command exceeding time/resource limit is stopped.
- Output is truncated at the configured limit.
- Untrusted jobs cannot read host secrets or access mounted host-control sockets.
- Cancellation and runner crash are represented accurately.
- The run is pinned to the expected commit SHA.

### Browser end-to-end tests

Use Playwright or the repository's existing framework. Start with a small controlled web application and a handful of critical journeys, for example:

- Open the home/dashboard route.
- Navigate to a projects page.
- Submit a form with valid and invalid input.
- Confirm an API error appears in a useful state.

These are examples; adapt to the real demo application. Do not claim broad browser coverage when only a few journeys are tested.

## 3. Golden regression demonstration

Maintain a known-good baseline and a deliberate, reversible defect in the demo application. Example: change a shared response transformation so the dashboard remains available while a project-detail page receives a wrong value or fails a defined assertion.

Test sequence:

1. Baseline commit passes the configured checks.
2. Bug commit is created and event processed.
3. Relevant test fails and names the broken journey/assertion.
4. The evidence record references the failure and revision.
5. The NVIDIA model receives the bounded diff and evidence through Nebius Token Factory.
6. The diagnosis mentions evidence that actually exists; fabricated references are rejected.
7. A candidate patch is created only if the patch feature is implemented and requested.
8. The same test is run against the candidate revision.
9. The UI reports the actual pass/fail/unverified result.

Keep this demo deterministic. Avoid choosing a regression that relies on external services or unstable timing.

## 4. Model quality evaluation

Do not evaluate the model only by whether its prose sounds confident. Create a small labelled set of representative diffs/failures and assess:

- Does the diagnosis identify the correct subsystem or failure class?
- Does it cite relevant evidence and avoid invented evidence?
- Does it distinguish observations from assumptions?
- Is the proposed action safe and relevant?
- Does the schema validate?
- Does the system fail gracefully when the model is wrong or unavailable?

Report sample size and limitations. A small demo evaluation does not prove general accuracy.

## 5. Required negative tests

- Invalid webhook signature does not create a run.
- Duplicate delivery does not trigger duplicate jobs.
- Model response cannot directly trigger arbitrary process execution.
- Provider failure cannot turn a failed test into a pass.
- A timed-out test cannot be labelled passed.
- Patch attempt with missing results remains unverified.
- User without project authorization cannot read source snippets, logs, screenshots, or model analysis.
- Redacted secrets do not appear in saved evidence or prompts.

## 6. Practical test matrix

| Scenario | Expected result |
|---|---|
| Valid push event | One accepted delivery and one logical run |
| Invalid signature | Rejected; no job created |
| Duplicate delivery id | Idempotent result; no duplicate job |
| All required tests pass | Test status is passed |
| One required test fails | Test status is failed, with check evidence |
| Runner timeout | Timed-out/incomplete; never silently passed |
| Nebius request unavailable | Test result remains intact; analysis marked failed/unavailable |
| Malformed model response | Analysis rejected/failed; safe UI error |
| Candidate patch passes configured checks | May be marked verified for those checks only |
| Candidate patch lacks test evidence | Unverified |
| Unauthorized run request | Access denied without leaking resource contents |

## 7. Before every demo or submission

- Run formatter/linter/type-check commands that actually exist.
- Run unit and integration suites.
- Run the golden regression scenario from baseline through diagnosis and fix verification.
- Verify actual Nebius model call if credentials/network permit.
- Test a no-credentials or provider-error state.
- Confirm README instructions on a clean checkout.
- Confirm no secrets or private repository content are committed.
- Record actual failures and limitations; do not convert skipped tests into passing tests.
