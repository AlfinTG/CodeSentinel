# Security Requirements and Threat Model

## 1. Security objective

CodeSentinel handles private source code, repository metadata, test output, provider credentials, and potentially untrusted build scripts. Treat it as a security-sensitive developer tool—not a harmless dashboard.

## 2. Protected assets

- Nebius API key, GitHub credentials, webhook secrets, and app private keys.
- Private repository source code and diffs.
- Environment variables and test/production secrets.
- Test outputs, logs, screenshots, and incident history.
- Candidate patches and repository write operations.
- User/project identity and authorization data.

## 3. Trust boundaries

1. Browser ↔ application API.
2. GitHub ↔ webhook endpoint.
3. Application API ↔ job coordinator/runner.
4. Untrusted repository code ↔ runner host.
5. Application backend ↔ Nebius Token Factory.
6. AI output ↔ patch/test execution.
7. App ↔ database/object storage.

Every boundary needs explicit input validation, authentication/authorization as applicable, limits, and safe error handling.

## 4. Required controls

### GitHub integration

- Validate `X-Hub-Signature-256` with HMAC-SHA256 over the exact original request body.
- Compare signatures using constant-time comparison.
- Reject missing/invalid signatures before processing the event.
- Use a high-entropy webhook secret stored outside source control.
- Enforce payload size limits and accept only supported event types.
- Prevent duplicate work using delivery identifiers and database uniqueness/idempotency.
- Use the least GitHub permissions required. Prefer read-only access unless a separately approved PR workflow needs more.
- Do not trust repository names/URLs from a payload alone; resolve installation and project authorization.

### Credential handling

- Keep provider and GitHub credentials on the server/worker only.
- Never place credentials in frontend bundles, source code, prompts, screenshots, URLs, or logs.
- Never commit `.env` or live credentials.
- Use `.env.example` for safe placeholders.
- Support credential rotation and revocation as practical.
- Ensure CI/demo logs mask secrets.

### Runner isolation

- Treat repository code and package lifecycle scripts as untrusted.
- Run outside the API web process in an isolated container or verified sandbox.
- Use a non-root identity and minimal filesystem mounts.
- Do not mount Docker/host control sockets.
- Restrict network egress by default; explicitly allow only what a test truly requires.
- Do not provide production secrets or broad cloud credentials to a test job.
- Enforce wall-clock timeouts, CPU/memory/process/disk limits, output truncation, and cancellation.
- Destroy job workspaces when finished, subject to needed artifact retention.
- Pin the exact commit/revision and avoid running commands derived directly from model text.

### AI and prompt injection

- Treat source comments, README files, issues, commit messages, and logs as untrusted data.
- Repository content must never override system/developer security policy or request secret disclosure.
- Send the minimum required context. Redact secrets and irrelevant private data before model calls.
- Constrain model outputs to a schema, validate data types/lengths, and reject unsupported actions.
- The model may recommend a command, but only configured allowlisted commands can run.
- A model-generated patch must be reviewed and tested in isolation.
- Never give the model direct authority to merge or deploy production code.

### Web/API security

- Authenticate users and enforce project ownership/team membership on all private endpoints.
- Validate request bodies, path/query parameters, and uploaded artifacts.
- Use secure cookies/session settings and CSRF protection when applicable to the selected auth model.
- Configure CORS narrowly; do not use permissive wildcard policy with credentialed requests.
- Rate-limit webhook handling, expensive runs, provider calls, and user-triggered retries.
- Return safe errors to clients; retain non-secret diagnostic details in restricted structured logs.
- Apply reasonable request and upload size caps.

### Storage and privacy

- Apply access control to source fragments, screenshots, logs, and reports.
- Encrypt transport using HTTPS in deployed environments and use provider-supported encryption at rest.
- Define retention and deletion behavior.
- Do not store full raw webhook events, prompts, or source trees unless necessary.
- Verify relevant provider terms/data handling before making privacy claims.

## 5. Patch and production safeguards

- Candidate patches are not automatically trusted.
- Apply patches only in an isolated branch, worktree, or verified sandbox.
- Run targeted and baseline regression tests before calling the patch verified.
- Require explicit human approval before opening a write-enabled PR if that capability is enabled.
- No automatic merge or production deployment in the MVP.
- If tests are unavailable, flaky, incomplete, or fail to run, label the result unverified—not successful.

## 6. Abuse and failure cases to test

- Missing/malformed/incorrect webhook signature.
- Duplicate webhook delivery and replay attempt.
- Oversized payload/log/test artifact.
- Unauthorized user requesting another project's run.
- Prompt injection in source comments or test output.
- Model response containing fabricated evidence IDs or a shell command.
- Runner timeout, process bomb attempt, network access attempt, and secret-file access attempt.
- Provider outage, rate limit, malformed result, and unexpected model id.
- Secret-like values in stack traces and environment output.

## 7. Incident response checklist

If a credential is exposed, revoke/rotate it immediately, remove it from active deployment configuration, inspect access logs, and follow the host's history-rewrite guidance if it was committed. Removing a key from the latest commit is not sufficient if it remains in git history. Record scope and remediation without copying the secret into reports.

## 8. Security references

- GitHub webhook signature validation: https://docs.github.com/en/webhooks/using-webhooks/validating-webhook-deliveries
- GitHub App security guidance: https://docs.github.com/en/apps/creating-github-apps/setting-up-a-github-app/best-practices-for-creating-a-github-app
- OWASP Top 10: https://owasp.org/www-project-top-ten/
