# Product Requirements Document (PRD)

## 1. Document status

- Product: CodeSentinel (working name)
- Status: Proposed requirements for an MVP
- Primary audience: developers and small engineering teams
- Proposed hackathon track: Coding and Agentic Engineering
- Priority notation: P0 = required for MVP; P1 = valuable if time allows; P2 = later

## 2. Product statement

CodeSentinel connects repository changes to deterministic tests and evidence-based AI diagnosis so developers can catch regressions, understand likely causes, and evaluate proposed fixes before release.

## 3. Problem statement

Code changes may break an unrelated route or workflow. Existing CI checks can report failure, but a developer still has to connect the changed code to the broken behavior and decide how to repair it. CodeSentinel adds traceability between the change, affected checks, observed failure, AI analysis, and verification attempt.

## 4. Users and jobs to be done

**Developer:** “When I push a change, tell me which relevant checks failed, show me evidence, and help me investigate the likely cause.”

**Team maintainer:** “When a regression occurs, let me see the affected commit, repeatable failure, history, and resolution status.”

**Hackathon judge/reviewer:** “Let me reproduce one complete workflow and see real evidence that the model and platform integration are essential to it.”

## 5. Product principles

1. Evidence before explanation.
2. Tests, not model confidence, determine whether behavior passes.
3. Minimize repository permissions and isolate execution.
4. Keep human approval for patches and any production-impacting action.
5. Make uncertainty visible.
6. Prefer one reliable end-to-end path over many incomplete features.
7. Never fabricate metrics, provider calls, tests, or deployment states.

## 6. Functional requirements

### P0 — repository events and project setup

- The user can configure one repository.
- The service accepts supported GitHub push and/or pull-request events.
- Each webhook is signature-verified using the original request body and configured secret.
- Duplicate delivery events are handled idempotently.
- Each accepted event creates or updates a persistent run record.
- The system stores source commit/PR identifiers and timestamps, without storing unnecessary repository data.

### P0 — test execution

- The project owner configures the allowed checks and their arguments.
- The runner executes checks in an isolated, bounded environment.
- The system captures status, duration, exit code, bounded output, and structured test results when available.
- A cancelled, timed-out, queued, running, failed, passed, or internally errored run is represented clearly.
- A run cannot be marked passed solely because no log was received.

### P0 — Nebius/NVIDIA diagnosis

- The backend calls an NVIDIA open-source model available to the project through Nebius Token Factory.
- The UI/documentation identifies the actual model and its actual use.
- The input includes relevant diffs/test/log evidence and excludes secrets.
- Model responses are validated before storage/display.
- The response contains evidence references, likely cause, affected behavior, confidence/uncertainty, and suggested next action.
- Provider errors and invalid outputs are handled without marking the analysis as successful.

### P0 — user interface

- The user can view projects and recent runs.
- A run detail view shows source change, execution status, checks, failed evidence, analysis status, and remediation status.
- Observed results and AI-generated hypotheses are visually distinct.
- Loading, empty, error, access-denied, and timeout states are supported.

### P0 — reproducibility and security

- The sample regression can be reproduced using documented steps.
- The repository includes automated tests for key workflow and security boundaries.
- The API key and webhook secret remain server-side.
- Test jobs run with resource limits and least privilege.

### P1 — candidate patch workflow

- The user can request a patch proposal.
- Patch generation/management occurs in an isolated working tree, branch, or verified sandbox.
- AI-generated shell commands are not executed arbitrarily.
- The relevant test suite is rerun against the candidate patch.
- A patch is labelled verified only when the required checks pass.
- The user must explicitly approve any merge or deployment outside this MVP.

### P1 — behavior baseline / test selection

- The project stores configured critical user journeys and known passing baseline references.
- A simple deterministic mapping links configured paths/files or named components to relevant tests.
- When tests are selected based on change impact, the UI explains the selection.
- If impact mapping is incomplete or uncertain, run the safe broader test set rather than falsely claiming complete coverage.

### P2 — later capabilities

- Local working-tree agent for uncommitted edits.
- IDE integration.
- Multiple repositories/teams and fine-grained organizations.
- Production telemetry and deployment integrations.
- Advanced dependency graph analysis.
- Notifications beyond the dashboard.
- Rich trend analytics and long-term repository memory.

## 7. Non-functional requirements

- Security: validate webhook signatures, authorize project access, redact secrets, isolate untrusted execution.
- Reliability: handle duplicate events, timeouts, retries, partial failures, and malformed model responses.
- Auditability: associate output with a run, commit, configured checks, model identifier, and timestamps.
- Usability: show a readable path from event to result without requiring the user to inspect raw logs first.
- Maintainability: small modules, typed boundary contracts, repeatable tests, and accurate setup documentation.
- Cost awareness: bound diff/log input, output length, retries, job runtime, and test scope.

## 8. MVP out of scope

- Guaranteed prediction of future bugs.
- General support for every programming language, CI provider, or test framework.
- Silent auto-merge, automatic production deployment, or unrestricted self-modification.
- Replacing established CI systems.
- Treating AI-generated results as deterministic proof.
- Running untrusted code directly on the API/web application host.
- A large multi-agent architecture unless a measured need justifies it.

## 9. Acceptance criteria

1. A valid test webhook creates exactly one run; an invalid signature is rejected.
2. A documented controlled regression produces a real failing test with captured evidence.
3. The UI shows the associated commit/change and failure status.
4. A real call to a verified NVIDIA open-source model through Nebius Token Factory returns a validated diagnosis or a clearly displayed provider/validation error.
5. Model explanations cite the evidence bundle and distinguish facts from hypotheses.
6. A proposed patch cannot change the production branch automatically.
7. If implemented, candidate-patch validation reruns tests and reports the actual outcome.
8. Tests cover webhook verification, idempotency, access control, run-state transitions, provider failures, response validation, and core regression workflow.
9. README setup commands have been run and verified by a teammate on a clean environment.
10. The application does not leak known test secrets in UI, logs, database records, or model prompts.

## 10. Product metrics to measure, not assume

- Time from accepted event to run start and final result.
- Number of configured tests run and number passed/failed/timed out.
- Ratio of diagnosis outputs that cite relevant evidence (reviewed against sample cases).
- Candidate patch pass rate on controlled regression examples.
- Model latency and token usage where returned by the provider.
- False-positive/false-negative observations from a manually labelled evaluation set.

Do not publish “bugs prevented,” “accuracy,” or “time saved” numbers without an evaluation method and actual measurements.

## 11. Hackathon constraints

The current official hackathon rules must be rechecked immediately before submission. The requirement is to build a working application that runs through Nebius Token Factory or Nebius AI Cloud and uses at least one NVIDIA open-source model. The Coding and Agentic Engineering track description emphasizes coding agents/developer tools that write, run, and test code in Token Factory sandboxes. Verify whether and how the team should use a sandbox, and do not claim sandbox execution unless implemented.

Official links:
- https://nebiusglobalaihackathon.devpost.com/rules
- https://nebiusglobalaihackathon.devpost.com/updates/46204-here-s-how-judging-works
- https://nebiusglobalaihackathon.devpost.com/updates/46205-how-to-build-a-winning-project
